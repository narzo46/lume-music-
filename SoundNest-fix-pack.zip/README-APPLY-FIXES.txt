SoundNest — fixes for Android APK build

This pack contains replacement files for the existing repository:
- .github/workflows/android.yml: removes dependency on missing ./gradlew and fixes Android SDK setup.
- app/src/main/res/values/themes.xml and AndroidManifest.xml: fixes a theme resource that inherited from itself.
- MainActivity.kt: fixes track selection after filtering, play button with an initially selected track, and seek slider range.

Apply:
1. Extract this ZIP over the root of https://github.com/narzo46/lume-music- (keep the folder structure).
2. Commit/push the changed files to the main branch, or upload the files using GitHub's web editor.
3. Open repository -> Actions -> Android APK Build. Wait for the workflow to finish.
4. Open the successful run -> Artifacts -> SoundNest-debug-apk -> download ZIP.
5. Extract the downloaded ZIP; the APK will be inside.

Important:
- This is a source-code fix pack, NOT an APK.
- I could read the repository but GitHub rejected write attempts with HTTP 403, and the current build run has no APK artifact. I cannot truthfully provide a built APK until the workflow runs successfully.
- The app currently plays audio files already present on the device. It does not yet implement downloading tracks from streaming platforms; protected tracks from services like Spotify/YouTube cannot simply be imported as offline audio.
